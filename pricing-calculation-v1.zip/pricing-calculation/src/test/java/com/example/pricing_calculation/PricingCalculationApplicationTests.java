package com.example.pricing_calculation;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;

import com.example.pricing_calculation.domain.PaymentMethod;
import com.example.pricing_calculation.domain.TransactionStatus;
import com.example.pricing_calculation.domain.TransactionType;
import com.example.pricing_calculation.dto.PageResponse;
import com.example.pricing_calculation.dto.TransactionHistoryCreateRequest;
import com.example.pricing_calculation.dto.TransactionHistoryResponse;
import com.example.pricing_calculation.dto.TransactionHistorySummaryResponse;
import com.example.pricing_calculation.service.BadRequestException;
import com.example.pricing_calculation.service.TransactionHistoryService;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.UUID;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.transaction.annotation.Transactional;

@SpringBootTest
class PricingCalculationApplicationTests {

	@Autowired
	private TransactionHistoryService transactionHistoryService;

	@Test
	void contextLoads() {
	}

	@Test
	@Transactional
	void transactionHistoryServiceCreatesSearchesSummarizesAndChangesStatus() {
		String code = "TXN-TEST-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
		LocalDateTime occurredAt = LocalDateTime.now();
		TransactionHistoryCreateRequest request = new TransactionHistoryCreateRequest();
		request.setTransactionCode(code);
		request.setType(TransactionType.PAYMENT_COMPLETED);
		request.setStatus(TransactionStatus.COMPLETED);
		request.setReservationCode("RSV-TEST-001");
		request.setParkingTicketCode("TICKET-TEST-001");
		request.setLicensePlate("51a-test");
		request.setVehicleType("CAR");
		request.setFloorNumber("B1");
		request.setParkingZone("A");
		request.setSlotNumber("A-01");
		request.setCustomerName("Integration Test");
		request.setCustomerPhone("0900000000");
		request.setPaymentMethod(PaymentMethod.QR_CODE);
		request.setAmount(new BigDecimal("45000"));
		request.setCurrency("VND");
		request.setDurationMinutes(120);
		request.setOccurredAt(occurredAt);

		TransactionHistoryResponse created = transactionHistoryService.create(request);

		assertNotNull(created.getId());
		assertEquals(code, created.getTransactionCode());
		assertEquals("51A-TEST", created.getLicensePlate());

		TransactionHistoryResponse fetched = transactionHistoryService.getByCode(code);
		assertEquals(created.getId(), fetched.getId());

		PageResponse<TransactionHistoryResponse> page = transactionHistoryService.search(
				code,
				null,
				null,
				null,
				null,
				null,
				occurredAt.minusMinutes(1),
				occurredAt.plusMinutes(1),
				null,
				null,
				0,
				10,
				"occurredAt",
				"desc"
		);
		assertEquals(1, page.getTotalElements());

		TransactionHistorySummaryResponse summary = transactionHistoryService.summary(
				occurredAt.minusMinutes(1),
				occurredAt.plusMinutes(1)
		);
		assertTrue(summary.getTotalTransactions() >= 1);
		assertTrue(summary.getTotalRevenue().compareTo(new BigDecimal("45000")) >= 0);

		TransactionHistoryResponse refunded = transactionHistoryService.changeStatus(
				created.getId(),
				TransactionStatus.REFUNDED
		);
		assertEquals(TransactionStatus.REFUNDED, refunded.getStatus());
	}

	@Test
	void transactionHistoryServiceRejectsNegativeAmount() {
		TransactionHistoryCreateRequest request = new TransactionHistoryCreateRequest();
		request.setType(TransactionType.PAYMENT_COMPLETED);
		request.setAmount(new BigDecimal("-1"));

		assertThrows(BadRequestException.class, () -> transactionHistoryService.create(request));
	}

}
