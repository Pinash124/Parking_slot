package com.example.pricing_calculation.repository;

import com.example.pricing_calculation.domain.TransactionHistory;
import java.util.List;
import java.util.Optional;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;

public interface TransactionHistoryRepository extends
        JpaRepository<TransactionHistory, Long>,
        JpaSpecificationExecutor<TransactionHistory> {

    boolean existsByTransactionCodeIgnoreCase(String transactionCode);

    Optional<TransactionHistory> findByTransactionCodeIgnoreCase(String transactionCode);

    List<TransactionHistory> findAllByOrderByOccurredAtDesc(Pageable pageable);
}
