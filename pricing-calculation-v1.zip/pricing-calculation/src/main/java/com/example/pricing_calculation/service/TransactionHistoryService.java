package com.example.pricing_calculation.service;

import com.example.pricing_calculation.domain.PaymentMethod;
import com.example.pricing_calculation.domain.TransactionHistory;
import com.example.pricing_calculation.domain.TransactionStatus;
import com.example.pricing_calculation.domain.TransactionType;
import com.example.pricing_calculation.dto.PageResponse;
import com.example.pricing_calculation.dto.TransactionHistoryCreateRequest;
import com.example.pricing_calculation.dto.TransactionHistoryResponse;
import com.example.pricing_calculation.dto.TransactionHistorySummaryResponse;
import com.example.pricing_calculation.dto.TransactionHistoryUpdateRequest;
import com.example.pricing_calculation.repository.TransactionHistoryRepository;
import jakarta.persistence.criteria.Predicate;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
public class TransactionHistoryService {

    private static final int MAX_PAGE_SIZE = 100;
    private static final Set<String> SORTABLE_FIELDS = Set.of(
            "id",
            "transactionCode",
            "type",
            "status",
            "reservationCode",
            "parkingTicketCode",
            "licensePlate",
            "amount",
            "occurredAt",
            "createdAt",
            "updatedAt"
    );

    private final TransactionHistoryRepository repository;

    public TransactionHistoryService(TransactionHistoryRepository repository) {
        this.repository = repository;
    }

    @Transactional
    public TransactionHistoryResponse create(TransactionHistoryCreateRequest request) {
        validateCreateRequest(request);
        if (hasText(request.getTransactionCode())
                && repository.existsByTransactionCodeIgnoreCase(request.getTransactionCode().trim())) {
            throw new BadRequestException("Transaction code already exists");
        }

        TransactionHistory transaction = new TransactionHistory();
        transaction.setTransactionCode(request.getTransactionCode());
        transaction.setType(request.getType());
        transaction.setStatus(request.getStatus());
        transaction.setReservationCode(request.getReservationCode());
        transaction.setParkingTicketCode(request.getParkingTicketCode());
        transaction.setLicensePlate(request.getLicensePlate());
        transaction.setVehicleType(request.getVehicleType());
        transaction.setFloorNumber(request.getFloorNumber());
        transaction.setParkingZone(request.getParkingZone());
        transaction.setSlotNumber(request.getSlotNumber());
        transaction.setCustomerName(request.getCustomerName());
        transaction.setCustomerPhone(request.getCustomerPhone());
        transaction.setPaymentMethod(request.getPaymentMethod());
        transaction.setAmount(request.getAmount());
        transaction.setCurrency(request.getCurrency());
        transaction.setDurationMinutes(request.getDurationMinutes());
        transaction.setGatewayReference(request.getGatewayReference());
        transaction.setOccurredAt(request.getOccurredAt());
        transaction.setSessionStartedAt(request.getSessionStartedAt());
        transaction.setSessionEndedAt(request.getSessionEndedAt());
        transaction.setNote(request.getNote());

        try {
            return TransactionHistoryResponse.from(repository.save(transaction));
        } catch (DataIntegrityViolationException ex) {
            throw new BadRequestException("Transaction code already exists or transaction data is invalid");
        }
    }

    @Transactional(readOnly = true)
    public TransactionHistoryResponse getById(Long id) {
        return TransactionHistoryResponse.from(findEntity(id));
    }

    @Transactional(readOnly = true)
    public TransactionHistoryResponse getByCode(String transactionCode) {
        TransactionHistory transaction = repository.findByTransactionCodeIgnoreCase(transactionCode)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found: " + transactionCode));
        return TransactionHistoryResponse.from(transaction);
    }

    @Transactional(readOnly = true)
    public PageResponse<TransactionHistoryResponse> search(
            String keyword,
            TransactionType type,
            TransactionStatus status,
            PaymentMethod paymentMethod,
            String licensePlate,
            String reservationCode,
            LocalDateTime from,
            LocalDateTime to,
            BigDecimal minAmount,
            BigDecimal maxAmount,
            int page,
            int size,
            String sortBy,
            String sortDirection) {
        PageRequest pageRequest = buildPageRequest(page, size, sortBy, sortDirection);
        Specification<TransactionHistory> specification = buildSpecification(
                keyword,
                type,
                status,
                paymentMethod,
                licensePlate,
                reservationCode,
                from,
                to,
                minAmount,
                maxAmount
        );
        Page<TransactionHistoryResponse> responsePage = repository.findAll(specification, pageRequest)
                .map(TransactionHistoryResponse::from);
        return PageResponse.from(responsePage);
    }

    @Transactional(readOnly = true)
    public List<TransactionHistoryResponse> recent(int limit) {
        int safeLimit = Math.max(1, Math.min(limit, 50));
        return repository.findAllByOrderByOccurredAtDesc(PageRequest.of(0, safeLimit)).stream()
                .map(TransactionHistoryResponse::from)
                .toList();
    }

    @Transactional(readOnly = true)
    public TransactionHistorySummaryResponse summary(LocalDateTime from, LocalDateTime to) {
        Specification<TransactionHistory> specification = buildSpecification(
                null,
                null,
                null,
                null,
                null,
                null,
                from,
                to,
                null,
                null
        );
        List<TransactionHistory> transactions = repository.findAll(specification);
        long total = transactions.size();
        long completed = countByStatus(transactions, TransactionStatus.COMPLETED);
        long pending = countByStatus(transactions, TransactionStatus.PENDING);
        long cancelled = countByStatus(transactions, TransactionStatus.CANCELLED);
        long failed = countByStatus(transactions, TransactionStatus.FAILED);
        long refunded = countByStatus(transactions, TransactionStatus.REFUNDED);
        BigDecimal totalRevenue = transactions.stream()
                .filter(transaction -> transaction.getStatus() == TransactionStatus.COMPLETED)
                .filter(transaction -> transaction.getType() == TransactionType.PAYMENT_COMPLETED
                        || transaction.getType() == TransactionType.CHECKOUT_COMPLETED)
                .map(TransactionHistory::getAmount)
                .filter(amount -> amount != null)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal averageAmount = total == 0
                ? BigDecimal.ZERO
                : totalRevenue.divide(BigDecimal.valueOf(Math.max(1, completed)), 2, RoundingMode.HALF_UP);

        return new TransactionHistorySummaryResponse(
                total,
                completed,
                pending,
                cancelled,
                failed,
                refunded,
                countReservationTransactions(transactions),
                countPaymentTransactions(transactions),
                countSessionTransactions(transactions),
                countSlotChangeTransactions(transactions),
                totalRevenue,
                averageAmount
        );
    }

    @Transactional
    public TransactionHistoryResponse update(Long id, TransactionHistoryUpdateRequest request) {
        TransactionHistory transaction = findEntity(id);
        validateUpdateRequest(request);

        if (request.getType() != null) {
            transaction.setType(request.getType());
        }
        if (request.getStatus() != null) {
            transaction.setStatus(request.getStatus());
        }
        if (request.getReservationCode() != null) {
            transaction.setReservationCode(request.getReservationCode());
        }
        if (request.getParkingTicketCode() != null) {
            transaction.setParkingTicketCode(request.getParkingTicketCode());
        }
        if (request.getLicensePlate() != null) {
            transaction.setLicensePlate(request.getLicensePlate());
        }
        if (request.getVehicleType() != null) {
            transaction.setVehicleType(request.getVehicleType());
        }
        if (request.getFloorNumber() != null) {
            transaction.setFloorNumber(request.getFloorNumber());
        }
        if (request.getParkingZone() != null) {
            transaction.setParkingZone(request.getParkingZone());
        }
        if (request.getSlotNumber() != null) {
            transaction.setSlotNumber(request.getSlotNumber());
        }
        if (request.getCustomerName() != null) {
            transaction.setCustomerName(request.getCustomerName());
        }
        if (request.getCustomerPhone() != null) {
            transaction.setCustomerPhone(request.getCustomerPhone());
        }
        if (request.getPaymentMethod() != null) {
            transaction.setPaymentMethod(request.getPaymentMethod());
        }
        if (request.getAmount() != null) {
            transaction.setAmount(request.getAmount());
        }
        if (request.getCurrency() != null) {
            transaction.setCurrency(request.getCurrency());
        }
        if (request.getDurationMinutes() != null) {
            transaction.setDurationMinutes(request.getDurationMinutes());
        }
        if (request.getGatewayReference() != null) {
            transaction.setGatewayReference(request.getGatewayReference());
        }
        if (request.getOccurredAt() != null) {
            transaction.setOccurredAt(request.getOccurredAt());
        }
        if (request.getSessionStartedAt() != null) {
            transaction.setSessionStartedAt(request.getSessionStartedAt());
        }
        if (request.getSessionEndedAt() != null) {
            transaction.setSessionEndedAt(request.getSessionEndedAt());
        }
        if (request.getNote() != null) {
            transaction.setNote(request.getNote());
        }

        return TransactionHistoryResponse.from(repository.save(transaction));
    }

    @Transactional
    public TransactionHistoryResponse changeStatus(Long id, TransactionStatus status) {
        if (status == null) {
            throw new BadRequestException("Status is required");
        }
        TransactionHistory transaction = findEntity(id);
        transaction.setStatus(status);
        return TransactionHistoryResponse.from(repository.save(transaction));
    }

    @Transactional
    public void delete(Long id) {
        TransactionHistory transaction = findEntity(id);
        repository.delete(transaction);
    }

    private TransactionHistory findEntity(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Transaction not found: " + id));
    }

    private PageRequest buildPageRequest(int page, int size, String sortBy, String sortDirection) {
        int safePage = Math.max(0, page);
        int safeSize = Math.max(1, Math.min(size, MAX_PAGE_SIZE));
        String safeSortBy = SORTABLE_FIELDS.contains(sortBy) ? sortBy : "occurredAt";
        Sort.Direction direction = "asc".equalsIgnoreCase(sortDirection)
                ? Sort.Direction.ASC
                : Sort.Direction.DESC;
        return PageRequest.of(safePage, safeSize, Sort.by(direction, safeSortBy));
    }

    private Specification<TransactionHistory> buildSpecification(
            String keyword,
            TransactionType type,
            TransactionStatus status,
            PaymentMethod paymentMethod,
            String licensePlate,
            String reservationCode,
            LocalDateTime from,
            LocalDateTime to,
            BigDecimal minAmount,
            BigDecimal maxAmount) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();
            if (hasText(keyword)) {
                String pattern = "%" + keyword.trim().toLowerCase() + "%";
                predicates.add(criteriaBuilder.or(
                        criteriaBuilder.like(criteriaBuilder.lower(root.get("transactionCode")), pattern),
                        criteriaBuilder.like(criteriaBuilder.lower(root.get("reservationCode")), pattern),
                        criteriaBuilder.like(criteriaBuilder.lower(root.get("parkingTicketCode")), pattern),
                        criteriaBuilder.like(criteriaBuilder.lower(root.get("licensePlate")), pattern),
                        criteriaBuilder.like(criteriaBuilder.lower(root.get("customerName")), pattern),
                        criteriaBuilder.like(criteriaBuilder.lower(root.get("customerPhone")), pattern),
                        criteriaBuilder.like(criteriaBuilder.lower(root.get("slotNumber")), pattern)
                ));
            }
            if (type != null) {
                predicates.add(criteriaBuilder.equal(root.get("type"), type));
            }
            if (status != null) {
                predicates.add(criteriaBuilder.equal(root.get("status"), status));
            }
            if (paymentMethod != null) {
                predicates.add(criteriaBuilder.equal(root.get("paymentMethod"), paymentMethod));
            }
            if (hasText(licensePlate)) {
                predicates.add(criteriaBuilder.like(
                        criteriaBuilder.lower(root.get("licensePlate")),
                        "%" + licensePlate.trim().toLowerCase() + "%"
                ));
            }
            if (hasText(reservationCode)) {
                predicates.add(criteriaBuilder.like(
                        criteriaBuilder.lower(root.get("reservationCode")),
                        "%" + reservationCode.trim().toLowerCase() + "%"
                ));
            }
            if (from != null) {
                predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("occurredAt"), from));
            }
            if (to != null) {
                predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get("occurredAt"), to));
            }
            if (minAmount != null) {
                predicates.add(criteriaBuilder.greaterThanOrEqualTo(root.get("amount"), minAmount));
            }
            if (maxAmount != null) {
                predicates.add(criteriaBuilder.lessThanOrEqualTo(root.get("amount"), maxAmount));
            }
            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }

    private void validateCreateRequest(TransactionHistoryCreateRequest request) {
        if (request == null) {
            throw new BadRequestException("Transaction request is required");
        }
        if (request.getType() == null) {
            throw new BadRequestException("Transaction type is required");
        }
        validateMoney(request.getAmount());
        validateDuration(request.getDurationMinutes());
        validateSessionTime(request.getSessionStartedAt(), request.getSessionEndedAt());
    }

    private void validateUpdateRequest(TransactionHistoryUpdateRequest request) {
        if (request == null) {
            throw new BadRequestException("Transaction update request is required");
        }
        validateMoney(request.getAmount());
        validateDuration(request.getDurationMinutes());
        validateSessionTime(request.getSessionStartedAt(), request.getSessionEndedAt());
    }

    private void validateMoney(BigDecimal amount) {
        if (amount != null && amount.compareTo(BigDecimal.ZERO) < 0) {
            throw new BadRequestException("Amount must be greater than or equal to 0");
        }
    }

    private void validateDuration(Integer durationMinutes) {
        if (durationMinutes != null && durationMinutes < 0) {
            throw new BadRequestException("Duration must be greater than or equal to 0");
        }
    }

    private void validateSessionTime(LocalDateTime startedAt, LocalDateTime endedAt) {
        if (startedAt != null && endedAt != null && endedAt.isBefore(startedAt)) {
            throw new BadRequestException("Session end time cannot be before start time");
        }
    }

    private long countByStatus(List<TransactionHistory> transactions, TransactionStatus status) {
        return transactions.stream()
                .filter(transaction -> transaction.getStatus() == status)
                .count();
    }

    private long countReservationTransactions(List<TransactionHistory> transactions) {
        return transactions.stream()
                .filter(transaction -> transaction.getType() == TransactionType.RESERVATION_CREATED
                        || transaction.getType() == TransactionType.RESERVATION_CANCELLED)
                .count();
    }

    private long countPaymentTransactions(List<TransactionHistory> transactions) {
        return transactions.stream()
                .filter(transaction -> transaction.getType() == TransactionType.PAYMENT_PENDING
                        || transaction.getType() == TransactionType.PAYMENT_COMPLETED)
                .count();
    }

    private long countSessionTransactions(List<TransactionHistory> transactions) {
        return transactions.stream()
                .filter(transaction -> transaction.getType() == TransactionType.SESSION_STARTED
                        || transaction.getType() == TransactionType.FEE_CALCULATED
                        || transaction.getType() == TransactionType.CHECKOUT_COMPLETED)
                .count();
    }

    private long countSlotChangeTransactions(List<TransactionHistory> transactions) {
        return transactions.stream()
                .filter(transaction -> transaction.getType() == TransactionType.SLOT_STATUS_CHANGED)
                .count();
    }

    private boolean hasText(String value) {
        return value != null && !value.trim().isEmpty();
    }
}
