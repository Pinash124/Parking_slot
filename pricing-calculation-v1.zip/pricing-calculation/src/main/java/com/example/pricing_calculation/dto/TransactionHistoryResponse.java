package com.example.pricing_calculation.dto;

import com.example.pricing_calculation.domain.PaymentMethod;
import com.example.pricing_calculation.domain.TransactionHistory;
import com.example.pricing_calculation.domain.TransactionStatus;
import com.example.pricing_calculation.domain.TransactionType;
import java.math.BigDecimal;
import java.time.LocalDateTime;

public class TransactionHistoryResponse {

    private final Long id;
    private final String transactionCode;
    private final TransactionType type;
    private final TransactionStatus status;
    private final String reservationCode;
    private final String parkingTicketCode;
    private final String licensePlate;
    private final String vehicleType;
    private final String floorNumber;
    private final String parkingZone;
    private final String slotNumber;
    private final String customerName;
    private final String customerPhone;
    private final PaymentMethod paymentMethod;
    private final BigDecimal amount;
    private final String currency;
    private final Integer durationMinutes;
    private final String gatewayReference;
    private final LocalDateTime occurredAt;
    private final LocalDateTime sessionStartedAt;
    private final LocalDateTime sessionEndedAt;
    private final String note;
    private final LocalDateTime createdAt;
    private final LocalDateTime updatedAt;

    private TransactionHistoryResponse(TransactionHistory transaction) {
        id = transaction.getId();
        transactionCode = transaction.getTransactionCode();
        type = transaction.getType();
        status = transaction.getStatus();
        reservationCode = transaction.getReservationCode();
        parkingTicketCode = transaction.getParkingTicketCode();
        licensePlate = transaction.getLicensePlate();
        vehicleType = transaction.getVehicleType();
        floorNumber = transaction.getFloorNumber();
        parkingZone = transaction.getParkingZone();
        slotNumber = transaction.getSlotNumber();
        customerName = transaction.getCustomerName();
        customerPhone = transaction.getCustomerPhone();
        paymentMethod = transaction.getPaymentMethod();
        amount = transaction.getAmount();
        currency = transaction.getCurrency();
        durationMinutes = transaction.getDurationMinutes();
        gatewayReference = transaction.getGatewayReference();
        occurredAt = transaction.getOccurredAt();
        sessionStartedAt = transaction.getSessionStartedAt();
        sessionEndedAt = transaction.getSessionEndedAt();
        note = transaction.getNote();
        createdAt = transaction.getCreatedAt();
        updatedAt = transaction.getUpdatedAt();
    }

    public static TransactionHistoryResponse from(TransactionHistory transaction) {
        return new TransactionHistoryResponse(transaction);
    }

    public Long getId() {
        return id;
    }

    public String getTransactionCode() {
        return transactionCode;
    }

    public TransactionType getType() {
        return type;
    }

    public TransactionStatus getStatus() {
        return status;
    }

    public String getReservationCode() {
        return reservationCode;
    }

    public String getParkingTicketCode() {
        return parkingTicketCode;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public String getFloorNumber() {
        return floorNumber;
    }

    public String getParkingZone() {
        return parkingZone;
    }

    public String getSlotNumber() {
        return slotNumber;
    }

    public String getCustomerName() {
        return customerName;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public PaymentMethod getPaymentMethod() {
        return paymentMethod;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public String getCurrency() {
        return currency;
    }

    public Integer getDurationMinutes() {
        return durationMinutes;
    }

    public String getGatewayReference() {
        return gatewayReference;
    }

    public LocalDateTime getOccurredAt() {
        return occurredAt;
    }

    public LocalDateTime getSessionStartedAt() {
        return sessionStartedAt;
    }

    public LocalDateTime getSessionEndedAt() {
        return sessionEndedAt;
    }

    public String getNote() {
        return note;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }
}
